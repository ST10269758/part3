/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.myapplication;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

/**
 *
 * @author RC_Student_lab
 */

public class MyApplication {
    public static void main(String[] args){
       class Login{
           String user;
           String password;
           String firstname;
           String lastname;
           
           boolean checkUserName(String user){
               if(user.length()>5 || user.indexOf('_')==-1){
                   return false;
           }
               else{
                   return true;
               }
       } 
           boolean checkPasswordComplexity(String password){
               String regex = "^(?=.*[0-9])" + "(?=.*[a-z])(?=.*[@#$%^&+=])" + "(?=\\S+$).{8,20}$";
               Pattern p =Pattern.compile(regex);
               Matcher m = p.matcher(password);
               return m.matches();
    }
           boolean loginUser(String user,String password){
               if(user.equals(this.user)&& password.equals(this.password)){
                   return true;
               }
               else{
                   return false;
               }
           }
           String returnLoginStatus(String user,String password){
               if(loginUser(user,password)){
                   return "Welcome" + firstname+lastname+"it is great to see you again.";
               }
               else{
                   return"Username or password incorrect try again.";
               }
           }
           void registerUser(String firstname,String lastname,String user, String password){
               if(checkUserName(user)){
                   this.user = user;
                   System.out.println("username successfully Captured");
                           
               }
               else{
                   System.out.println("username is not correctly formatted, please ensure that your usernamecontains an underscore and is no more than 5characters long.");
                   
               }
               if(checkPasswordComplexity(password)){
                   this.password = password;
                   System.out.println("password successfully captured");
               }
               else{
                   System.out.println("password is not correctly formatted, please ensure that the password contains atleast 8 characters,a capital letter, a number and a special character.");
                   
               }
               if(checkUserName(user)&& checkPasswordComplexity(password)){
                   this.firstname = firstname;
                   this.lastname = lastname;
                   System.out.println(returnLoginStatus(user,password));
               }
           }
       }
       class Registration{
           public static void main(String[] args){
               Scanner sc = new Scanner(System.in);
               System.out.print("enter username:");
               String user = sc.nextLine();
               System.out.print("enter password:");
               String password = sc.nextLine();
               System.out.print("enter first name:");
               String firstname = sc.nextLine();
               System.out.print("enter last name:");
               String lastname = sc.nextLine();
               sc.close();
               Login user1 = new Login();
               user1.registerUser(firstname, lastname, user, password);
           }
       }
    }
         public class Task{
           boolean checkTaskDescription(String taskDescription){
               if(taskDescription.length()<= 50){
                   return true;
               }
               else{
                   return false;
               }      
    }
           public String createTaskID(String taskName, int taskNumber, String developerName){
             String taskID = taskName.substring(0,2)+":"+
                     Integer.toString(taskNumber)+":"+ developerName.substring(developerName.length()-3);
                        return taskID.toUpperCase();
         }
           public String printTaskDetails(String taskName, int taskNumber, String taskDescription, String devFirstName, String devLastName, int taskDuration
           , String taskID, String taskStatus){
               String printValue = taskName+ "" + Integer.toString(taskNumber)+""+ taskDescription + "" + devFirstName+ "" + devLastName+ "" + Integer.toString( taskDuration)
                   +"" + taskID+ " " + taskStatus;
                       return printValue;
           }
           public int returnTotalHours(int numTask, int enteredHours){
               int totalHours = 0;
               for(int i =0; i< numTask; i++){
                   totalHours+=enteredHours;
               }
                   return totalHours;
           }
           public int addSlackTime(int numTasks, int duration, int slackTime){
               int totalTimeWithSlack = 0;
               for(int i = 1; i< numTasks; i++){
                   slackTime+= slackTime;
                   totalTimeWithSlack = slackTime+duration;
                   JOptionPane.showMessageDialog(null,"slack currently is "+ slackTime);
               }
                      return totalTimeWithSlack;
           }
           public String [] populateDeveloperArray(){
               String [] developer= new String[] {"Mike Smith", "Edward Harrington", "Samantha Paulson", "Glenda Oberholzer"};
               return developer;
           }
           public String [] populateTaskNameArray(){
               String [] TaskName = new String[]{"Creat Login", "Create Add Features","Create Reports", "Create Array"};
                    return TaskName;
                   
           }
           }
         
             }
         

     
    

    
    