
import java.util.ArrayList;
import java.util.Scanner;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author RC_Student_lab
 */
   public class storedata {
    ArrayList<String> developers;
    private ArrayList<String> taskNames;
    private ArrayList<Integer> taskIDs;
    private ArrayList<Integer> taskDurations;
    private ArrayList<String> taskStatuses;
    
    public storedata(){
        developers = new ArrayList<>();
        taskNames = new ArrayList<>();
        taskIDs = new ArrayList<>();
        taskDurations = new ArrayList<>();
        taskStatuses = new ArrayList<>();
        
    }
    public void addTask(String developer, String taskName, int taskDuration,String taskStatus){
        developers.add(developer);
        taskNames.add(taskName);
        taskIDs.add(taskIDs.size()+ 1);
        taskDurations.add(taskDuration);
        taskStatuses.add(taskStatus);
    }
      
     public void displayDoneTasks(){
         for(int i = 0;i < taskStatuses.size(); i++){
             if(taskStatuses.get(i).equals("Done")){
                 System.out.println("Developer:" + developers.get(i));
                 System.out.println("Task Name:" + taskNames.get(i));
                 System.out.println("Task Duration:" + taskDurations.get(i));
                 System.out.println();
             }
         }
     }
    public void displayLongestTask(){
        int maxDuration = 0;
        int maxIndex = 0;
        for (int i = 0; i< taskDurations.size(); i++){
            if(taskDurations.get(i)> maxDuration){
                maxDuration = taskDurations.get(i);
                maxIndex =i;
                
            }
        }
        System.out.println("Developer:" + developers.get(maxIndex));
        System.out.println("Task Duration:" + taskDurations.get(maxDuration));
    }
    public void searchTaskByName(String taskName){
        for(int i =0; i<taskNames.size(); i++){
            if(taskNames.get(i).equals(taskName)){
            System.out.println("Task Name:" + taskNames.get(i) );
            System.out.println("Developer:" + developers.get(i));
            System.out.println("Task Status:" + taskStatuses.get(i));
            return;
        }
            
        }
        System.out.println("Task not found");
    }
    public void searchTasksBydeveloper(String developer){
        for(int i = 0; i< developers.size(); i++){
        if(developers.get(i).equals(developer)){
            System.out.println("Task Name:" + taskNames.get(i));
            System.out.println("Task Status:"+ taskStatuses.get(i));
        }
    }
    }
    public void deleteTask(String taskName){
        for(int i = 0; i< taskNames.size(); i++){
            if(taskNames.get(i).equals(taskName)){
                developers.remove(i);
                taskNames.remove(i);
                taskIDs.remove(i);
                taskDurations.remove(i);
                taskStatuses.remove(i);
                System.out.println("Task deleted");
                return;
            }
        }
        System.out.println("Task not found");
    }
    public void displayReport(){
        for(int i =0; i< taskNames.size(); i++){
            System.out.println("Task ID:" + taskIDs.get(i));
            System.out.println("Task Name: " + taskNames.get(i));
            System.out.println("Developer:" + developers.get(i));
            System.out.println("Task Duration:" + taskDurations.get(i));
            System.out.println("Task Status:"+ taskStatuses.get(i));
            System.out.println();
        }
    }
   public static void main(String[] args){
       storedata storeData = new storedata();
       storeData.addTask("Mike Smith", "Create Login",5,"To Do");
       storeData.addTask("Edward Harrison", "Create Add Feature",8 ,"Doing");
       storeData.addTask("Samantha Paulson","Create Reports",2,"Done");
       storeData.addTask("Glenda Oberholzer","Add Arrays",11,"To Do");
       
       Scanner scanner = new Scanner(System.in);
       while (true){
           System.out.println("1.Display done tasks");
           System.out.println("2.Display longest task");
           System.out.println("3.Search task by name");
           System.out.println("4.Search task by developer");         
           System.out.println("5.Delete task");
           System.out.println("6.Display report");         
           System.out.println("7.Exit");         
           System.out.print("Enter your choice:");
           int choice = scanner.nextInt();
           switch(choice){
               case 1:
                   storeData.displayDoneTasks();
                   break;
               case 2:
                   storeData.displayLongestTask();
                   break;
               case 3:
                   System.out.print("Enter task name:") ;
                   String taskName = scanner.next();
                   storeData.searchTaskByName(taskName);
                   break;
               case 4:
                   System.out.print("Enter developer name:");
                   String developer = scanner.next();
                   storeData.searchTasksBydeveloper(developer);
                   break;
               case 5:
                   System.out.print("Enter task name:");
                   taskName = scanner.next();
                   storeData.deleteTask(taskName);
                   break;
               case 6:
                   storeData.displayReport();
                   break;
               case 7:
                   System.exit(0);
                   break;
               default:
                   System.out.println("Invalid choice");    
           }
           }
       }
       
   }

   