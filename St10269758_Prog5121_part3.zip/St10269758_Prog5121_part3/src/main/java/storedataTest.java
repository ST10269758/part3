
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author RC_Student_lab
 */
public class storedataTest {
    
     @Test
    public  void testAddTask(){
        storedata storeData = new storedata();
        storeData.addTask("Mike Smith", "Create Login",5,"To Do");
        assertEquals(1,storedata.developers.size());
        assertEquals(1,storedata.taskNames.size());
        assertEquals(5,storedata.taskDurations.get(0));
        assertEquals("To Do",storedata.taskStatuses.get(0));
    
    }
    @Test
    public void testDisplayDoneTasks(){
        storedata storedata = new storedata();
        storedata.addTask("Mike Smith","Create Login",5,"To Do");
        storedata.addTask("Samantha Paulson","Create Reports",2,"Done");
        storedata.displayDoneTasks();
        // verify output
    } 
    @Test
    public void testDisplayLongestTask(){
        storedata storedata = new storedata();
        storedata.addTask("Mike Smith","Create Login",5,"To Do");
        storedata.addTask("Glenda Oberholzer","Add Arrays",11,"To Do");
        storedata.displayLongestTask();
    }
    @Test
    public void testSearchTaskByName(){
        storedata storedata = new storedata();
        storedata.addTask("Mike Smith","Create Login",5,"To Do");
        storedata.searchTaskByName("Create Login");
       
    }
    @Test
    public void testSearchTaskByDeveloper(){
        storedata storedata = new storedata();
        storedata.addTask("Mike Smith","Create Login",5,"To Do");
        storedata.addTask("Mike Smith","Create Add Features",8,"Doing");
        storedata.searchTasksBydeveloper("Mike Smith");
        
    }
    @Test
    public void testDeleteTask(){
        storedata storedata = new storedata();
        storedata.addTask("Mike Smith","Create Login",5,"To Do");
        storedata.deleteTask("Create Login");
        assertEquals(0,storedata.developers.size());
        assertEquals(0,storedata.taskNames.size());
        assertEquals(0,storedata.taskDurations.size());
        assertEquals(0,storedata.taskStatuses.size());
        
        
    }
    @Test
    public void testDisplayReport(){
        storedata storedata = new storedata();
        storedata.addTask("Mike Smith","Create Login",5,"To Do");
        storedata.addTask("Samantha Paulson","Create Reports",2,"Done");
        storedata.displayReport();
    }
}
    


